from pathlib import Path
from logic import weekly_summary, habit_status

def make_weekly_report(entries, any_date=None):
    summary = weekly_summary(entries, any_date)
    lines = [
        "HEALTHY HABIT TRACKER - WEEKLY REPORT",
        f"Week: {summary['start']} to {summary['end']}",
        f"Days recorded: {summary['days_recorded']}/7",
        "",
    ]
    labels = {
        "reading_minutes": "Reading (minutes)",
        "exercise_minutes": "Exercise (minutes)",
        "water_glasses": "Hydration (glasses)",
    }
    for key, label in labels.items():
        pct = summary["completion"][key]
        lines.extend([
            f"{label}: {summary['totals'][key]} / {summary['goals'][key]}",
            f"Progress: {pct:.1f}% - {habit_status(pct)}",
            "",
        ])
    lines.append("Daily records:")
    if not summary["entries"]:
        lines.append("No entries recorded for this week.")
    for e in summary["entries"]:
        lines.append(
            f"{e.entry_date}: reading {e.reading_minutes} min, "
            f"exercise {e.exercise_minutes} min, water {e.water_glasses} glasses"
        )
    return "\n".join(lines)

def save_report(entries, output_path):
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(make_weekly_report(entries), encoding="utf-8")
    return path
