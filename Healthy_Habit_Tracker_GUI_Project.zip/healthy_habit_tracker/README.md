# Healthy Habit Tracker

A beginner-friendly Python desktop application with a Tkinter graphical interface for recording reading, exercise and hydration habits over a week.

## Features
- Professional Tkinter desktop interface with dashboard, daily entry form and searchable history
- Menu-driven terminal interface
- Daily records for reading minutes, exercise minutes and water glasses
- Input validation and duplicate-date confirmation
- Local JSON persistence with recovery from a damaged JSON file
- Search by date or notes
- Weekly totals, goal progress and status indicators
- CSV import/export, text report export and Matplotlib charts
- Sample data and automated unit tests

## Requirements
- Python 3.10 or later
- Matplotlib (for charts only)

## Run on Windows
1. Extract the ZIP file.
2. Open the `healthy_habit_tracker` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

If activation is blocked in PowerShell, you can skip the virtual environment and run `python -m pip install -r requirements.txt`, then `python main.py`.

## Menu
1. Add/update a daily record
2. View records
3. Search records
4. Weekly summary
5. Export weekly report as TXT
6. Export records as CSV
7. Import records from CSV
8. Create charts as PNG
0. Save and exit

## Data format
The JSON data file is created automatically at `data/habits.json`. CSV import expects these column names:

`entry_date,reading_minutes,exercise_minutes,water_glasses,notes`

Dates use `YYYY-MM-DD`. One record is stored per date. Import skips dates already present.

## Weekly goals
Edit the `GOALS` dictionary in `config.py` to change the default goals:
- Reading: 140 minutes per week
- Exercise: 150 minutes per week
- Hydration: 56 glasses per week

Progress status is `GOAL ACHIEVED` at 100%, `ON TRACK` at 70–99.9%, and `NEEDS ATTENTION` below 70%.

## Sample data
A small sample CSV is included at `data/sample_habits.csv`. Use menu option 7 to import it.

## Tests
Run:

```bash
python -m unittest discover -s tests -v
```

## Graphical interface
Run `python main.py` to launch the desktop GUI. The dashboard shows the current week's totals and progress bars. Use the tabs to add records and search history. The footer buttons export CSV and weekly text reports. The dashboard can generate PNG trend charts.

Tkinter is included with most standard Windows Python installations. If Python was installed without Tcl/Tk support, modify `main.py` to run the terminal interface via `from ui import run; run()`.
