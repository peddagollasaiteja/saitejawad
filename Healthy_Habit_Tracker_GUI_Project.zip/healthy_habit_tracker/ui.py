from datetime import date
from pathlib import Path
from config import EXPORT_DIR, GOALS
from models import HabitEntry
from validation import clean_date, clean_integer, clean_notes
from storage import load_entries, save_entries, export_csv, import_csv
from logic import weekly_summary, habit_status, search_entries
from reports import make_weekly_report
from plotting import create_charts

def ask_number(prompt, field, maximum=1440):
    while True:
        try:
            return clean_integer(input(prompt), field, 0, maximum)
        except ValueError as exc:
            print("Invalid input:", exc)

def add_entry(entries):
    raw_date = input(f"Date YYYY-MM-DD [{date.today().isoformat()}]: ").strip()
    try:
        entry_date = clean_date(raw_date or date.today().isoformat())
    except ValueError as exc:
        print("Invalid date:", exc)
        return
    reading = ask_number("Reading minutes: ", "Reading minutes")
    exercise = ask_number("Exercise minutes: ", "Exercise minutes")
    water = ask_number("Water glasses (0-30): ", "Water glasses", 30)
    try:
        notes = clean_notes(input("Notes (optional, max 200 characters): "))
    except ValueError as exc:
        print("Invalid notes:", exc)
        return
    entry = HabitEntry(entry_date, reading, exercise, water, notes)
    existing = next((i for i, e in enumerate(entries) if e.entry_date == entry_date), None)
    if existing is not None:
        answer = input("A record exists for this date. Replace it? (y/n): ").lower()
        if answer != "y":
            print("No changes made.")
            return
        entries[existing] = entry
    else:
        entries.append(entry)
    save_entries(entries)
    print("Habit record saved.")

def show_entries(entries):
    if not entries:
        print("No habit records yet.")
        return
    print("\nDATE        READING  EXERCISE  WATER  NOTES")
    print("-" * 70)
    for e in sorted(entries, key=lambda x: x.entry_date, reverse=True):
        print(f"{e.entry_date}  {e.reading_minutes:>7}  {e.exercise_minutes:>8}  "
              f"{e.water_glasses:>5}  {e.notes[:20]}")

def show_summary(entries):
    raw = input(f"Any date in the week [today {date.today().isoformat()}]: ").strip()
    try:
        selected_date = clean_date(raw or date.today().isoformat())
    except ValueError as exc:
        print("Invalid date:", exc)
        return
    s = weekly_summary(entries, selected_date)
    print(f"\nWEEKLY SUMMARY: {s['start']} to {s['end']}")
    print(f"Days with records: {s['days_recorded']}/7")
    labels = [
        ("reading_minutes", "Reading", "minutes"),
        ("exercise_minutes", "Exercise", "minutes"),
        ("water_glasses", "Hydration", "glasses"),
    ]
    for key, label, unit in labels:
        pct = s["completion"][key]
        print(f"{label}: {s['totals'][key]} {unit} / {s['goals'][key]} goal "
              f"({pct:.1f}%) - {habit_status(pct)}")

def run():
    entries = load_entries()
    menu = """
========== HEALTHY HABIT TRACKER ==========
1. Add or update daily habit record
2. View all records
3. Search records
4. Weekly summary
5. Export report (TXT)
6. Export records (CSV)
7. Import records (CSV)
8. Create charts (PNG)
0. Save and exit
"""
    while True:
        print(menu)
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_entry(entries)
        elif choice == "2":
            show_entries(entries)
        elif choice == "3":
            results = search_entries(entries, input("Search date or notes: "))
            show_entries(results)
        elif choice == "4":
            show_summary(entries)
        elif choice == "5":
            EXPORT_DIR.mkdir(parents=True, exist_ok=True)
            path = EXPORT_DIR / "weekly_report.txt"
            path.write_text(make_weekly_report(entries), encoding="utf-8")
            print(f"Report saved to {path}")
        elif choice == "6":
            path = EXPORT_DIR / "habit_records.csv"
            export_csv(entries, path)
            print(f"CSV saved to {path}")
        elif choice == "7":
            raw_path = input("CSV file path: ").strip().strip('"')
            try:
                incoming, rejected = import_csv(Path(raw_path))
                known = {e.entry_date for e in entries}
                added = 0
                for entry in incoming:
                    if entry.entry_date not in known:
                        entries.append(entry)
                        known.add(entry.entry_date)
                        added += 1
                save_entries(entries)
                print(f"Imported {added} new record(s); {len(rejected)} row(s) rejected.")
                for line, reason in rejected:
                    print(f"  Row {line}: {reason}")
            except (OSError, ValueError) as exc:
                print("Import failed:", exc)
        elif choice == "8":
            try:
                paths = create_charts(entries, EXPORT_DIR)
                print("Charts saved:")
                for path in paths:
                    print(" ", path)
            except (RuntimeError, ValueError) as exc:
                print("Could not create charts:", exc)
        elif choice == "0":
            save_entries(entries)
            print("Your records are saved. Goodbye!")
            break
        else:
            print("Please choose a valid menu option.")
