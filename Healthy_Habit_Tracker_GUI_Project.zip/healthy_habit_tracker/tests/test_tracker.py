import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validation import clean_date, clean_integer, clean_notes
from models import HabitEntry
from logic import weekly_summary, habit_status, search_entries

class ValidationTests(unittest.TestCase):
    def test_valid_integer(self):
        self.assertEqual(clean_integer("25", "Reading"), 25)

    def test_reject_negative(self):
        with self.assertRaises(ValueError):
            clean_integer("-1", "Reading")

    def test_reject_decimal(self):
        with self.assertRaises(ValueError):
            clean_integer("2.5", "Reading")

    def test_valid_date_format(self):
        self.assertEqual(clean_date("2020-01-01"), "2020-01-01")

    def test_reject_bad_date(self):
        with self.assertRaises(ValueError):
            clean_date("01/12/2025")

    def test_notes_length(self):
        with self.assertRaises(ValueError):
            clean_notes("x" * 201)

class LogicTests(unittest.TestCase):
    def setUp(self):
        self.entries = [
            HabitEntry("2026-11-17", 20, 30, 8, "walk"),
            HabitEntry("2026-11-18", 40, 20, 7, "read"),
        ]

    def test_weekly_totals(self):
        result = weekly_summary(self.entries, "2026-11-18")
        self.assertEqual(result["totals"]["reading_minutes"], 60)
        self.assertEqual(result["totals"]["exercise_minutes"], 50)
        self.assertEqual(result["totals"]["water_glasses"], 15)

    def test_status(self):
        self.assertEqual(habit_status(100), "GOAL ACHIEVED")
        self.assertEqual(habit_status(80), "ON TRACK")
        self.assertEqual(habit_status(20), "NEEDS ATTENTION")

    def test_search_notes(self):
        self.assertEqual(len(search_entries(self.entries, "walk")), 1)

if __name__ == "__main__":
    unittest.main()
