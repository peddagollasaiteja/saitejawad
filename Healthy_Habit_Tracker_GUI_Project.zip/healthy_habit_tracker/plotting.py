from pathlib import Path
from collections import defaultdict

def create_charts(entries, output_dir):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise RuntimeError("Matplotlib is not installed. Run: pip install -r requirements.txt")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    ordered = sorted(entries, key=lambda e: e.entry_date)
    dates = [e.entry_date for e in ordered]
    if not ordered:
        raise ValueError("Add at least one habit entry before creating charts.")

    charts = []
    metrics = [
        ("reading_minutes", "Reading minutes", "reading_trend.png"),
        ("exercise_minutes", "Exercise minutes", "exercise_trend.png"),
        ("water_glasses", "Water glasses", "hydration_trend.png"),
    ]
    for attr, title, filename in metrics:
        plt.figure(figsize=(9, 4.5))
        plt.plot(dates, [getattr(e, attr) for e in ordered], marker="o")
        plt.title(title + " by day")
        plt.xlabel("Date")
        plt.ylabel(title)
        plt.xticks(rotation=35, ha="right")
        plt.tight_layout()
        path = output_dir / filename
        plt.savefig(path, dpi=150)
        plt.close()
        charts.append(path)
    return charts
