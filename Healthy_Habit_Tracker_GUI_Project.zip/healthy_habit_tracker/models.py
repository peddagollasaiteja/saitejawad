from dataclasses import dataclass, asdict
from datetime import date

@dataclass
class HabitEntry:
    entry_date: str
    reading_minutes: int
    exercise_minutes: int
    water_glasses: int
    notes: str = ""

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        return cls(
            entry_date=data["entry_date"],
            reading_minutes=int(data["reading_minutes"]),
            exercise_minutes=int(data["exercise_minutes"]),
            water_glasses=int(data["water_glasses"]),
            notes=str(data.get("notes", "")),
        )

    @property
    def total_active_minutes(self):
        return self.reading_minutes + self.exercise_minutes
