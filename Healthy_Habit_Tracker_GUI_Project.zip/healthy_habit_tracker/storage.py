import csv
import json
import shutil
from config import DATA_DIR, JSON_FILE, CSV_FILE
from models import HabitEntry

def ensure_data_files():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    JSON_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not JSON_FILE.exists():
        save_entries([])

def load_entries():
    ensure_data_files()
    try:
        with JSON_FILE.open("r", encoding="utf-8") as file:
            raw = json.load(file)
        if not isinstance(raw, list):
            raise ValueError("The data file must contain a list.")
        entries = []
        for item in raw:
            try:
                entries.append(HabitEntry.from_dict(item))
            except (KeyError, TypeError, ValueError):
                continue
        return entries
    except (json.JSONDecodeError, OSError, ValueError):
        backup = JSON_FILE.with_suffix(".corrupt.json")
        try:
            shutil.copy2(JSON_FILE, backup)
        except OSError:
            pass
        save_entries([])
        print(f"Warning: damaged data file backed up to {backup.name}; starting with empty data.")
        return []

def save_entries(entries):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp_file = JSON_FILE.with_suffix(".tmp")
    with temp_file.open("w", encoding="utf-8") as file:
        json.dump([entry.to_dict() for entry in entries], file, indent=2)
    temp_file.replace(JSON_FILE)

def export_csv(entries, path=CSV_FILE):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=[
            "entry_date", "reading_minutes", "exercise_minutes", "water_glasses", "notes"
        ])
        writer.writeheader()
        for entry in sorted(entries, key=lambda e: e.entry_date):
            writer.writerow(entry.to_dict())

def import_csv(path):
    imported, rejected = [], []
    with path.open("r", newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        required = {"entry_date", "reading_minutes", "exercise_minutes", "water_glasses"}
        if not required.issubset(set(reader.fieldnames or [])):
            raise ValueError("CSV must contain: " + ", ".join(sorted(required)))
        from validation import clean_date, clean_integer, clean_notes
        for line_no, row in enumerate(reader, start=2):
            try:
                imported.append(HabitEntry(
                    clean_date(row["entry_date"]),
                    clean_integer(row["reading_minutes"], "Reading minutes"),
                    clean_integer(row["exercise_minutes"], "Exercise minutes"),
                    clean_integer(row["water_glasses"], "Water glasses", 0, 30),
                    clean_notes(row.get("notes", "") or ""),
                ))
            except (ValueError, TypeError) as exc:
                rejected.append((line_no, str(exc)))
    return imported, rejected
