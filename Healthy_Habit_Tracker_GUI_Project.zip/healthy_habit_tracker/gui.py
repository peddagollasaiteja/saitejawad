import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date
from pathlib import Path
import os
import sys

from config import EXPORT_DIR, GOALS
from models import HabitEntry
from storage import load_entries, save_entries, export_csv, import_csv
from validation import clean_date, clean_integer, clean_notes
from logic import weekly_summary, search_entries, habit_status
from reports import make_weekly_report
from plotting import create_charts

BG = "#F4F7FB"
CARD = "#FFFFFF"
NAVY = "#172B4D"
MUTED = "#667085"
BLUE = "#356AE6"
GREEN = "#159A72"
ORANGE = "#E69A32"
RED = "#D94B4B"

class HabitTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Healthy Habit Tracker")
        self.root.geometry("1120x760")
        self.root.minsize(960, 650)
        self.root.configure(bg=BG)
        self.entries = load_entries()
        self._style()
        self._build()
        self.refresh()

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD)
        style.configure("TLabel", background=BG, foreground=NAVY, font=("Segoe UI", 10))
        style.configure("Card.TLabel", background=CARD, foreground=NAVY, font=("Segoe UI", 10))
        style.configure("Title.TLabel", background=BG, foreground=NAVY, font=("Segoe UI", 23, "bold"))
        style.configure("Sub.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("Metric.TLabel", background=CARD, foreground=NAVY, font=("Segoe UI", 21, "bold"))
        style.configure("MetricName.TLabel", background=CARD, foreground=MUTED, font=("Segoe UI", 9, "bold"))
        style.configure("Treeview", rowheight=31, font=("Segoe UI", 9), background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#EAF0FA", foreground=NAVY)
        style.map("Treeview", background=[("selected", "#DCE7FF")], foreground=[("selected", NAVY)])
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9), font=("Segoe UI", 9, "bold"))
        style.configure("Blue.Horizontal.TProgressbar", troughcolor="#E9EEF6", background=BLUE, thickness=10)
        style.configure("Green.Horizontal.TProgressbar", troughcolor="#E9EEF6", background=GREEN, thickness=10)
        style.configure("Orange.Horizontal.TProgressbar", troughcolor="#E9EEF6", background=ORANGE, thickness=10)

    def _button(self, parent, text, command, color=BLUE):
        return tk.Button(parent, text=text, command=command, bg=color, fg="white",
                         activebackground=color, activeforeground="white",
                         relief="flat", bd=0, padx=14, pady=9,
                         font=("Segoe UI", 9, "bold"), cursor="hand2")

    def _build(self):
        header = tk.Frame(self.root, bg=NAVY, height=82)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="♥", bg=NAVY, fg="#8FC5FF",
                 font=("Segoe UI", 27, "bold")).pack(side="left", padx=(24, 12))
        title_box = tk.Frame(header, bg=NAVY)
        title_box.pack(side="left", pady=15)
        tk.Label(title_box, text="Healthy Habit Tracker", bg=NAVY, fg="white",
                 font=("Segoe UI", 19, "bold")).pack(anchor="w")
        tk.Label(title_box, text="Build consistency, one day at a time",
                 bg=NAVY, fg="#C9D7EF", font=("Segoe UI", 9)).pack(anchor="w")
        tk.Label(header, text=date.today().strftime("%A, %d %B %Y"),
                 bg=NAVY, fg="#DCE7FF", font=("Segoe UI", 10)).pack(side="right", padx=25)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=20)
        tk.Label(body, text="Your wellness overview", bg=BG, fg=NAVY,
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(body, text="Track your weekly goals and keep your daily habits on course.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(3, 14))

        self.metric_frame = tk.Frame(body, bg=BG)
        self.metric_frame.pack(fill="x", pady=(0, 15))
        self.metric_vars = {}
        metrics = [
            ("reading_minutes", "READING", "min", BLUE),
            ("exercise_minutes", "EXERCISE", "min", GREEN),
            ("water_glasses", "HYDRATION", "glasses", ORANGE),
        ]
        for key, label, unit, color in metrics:
            card = tk.Frame(self.metric_frame, bg=CARD, highlightbackground="#E6EBF2",
                            highlightthickness=1, padx=16, pady=13)
            card.pack(side="left", fill="both", expand=True, padx=(0, 10))
            tk.Label(card, text=label, bg=CARD, fg=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w")
            var = tk.StringVar(value=f"0 {unit}")
            self.metric_vars[key] = var
            tk.Label(card, textvariable=var, bg=CARD, fg=color,
                     font=("Segoe UI", 21, "bold")).pack(anchor="w", pady=(4, 0))
            goal_var = tk.StringVar(value="Weekly goal: —")
            setattr(self, f"{key}_goal_var", goal_var)
            tk.Label(card, textvariable=goal_var, bg=CARD, fg=MUTED,
                     font=("Segoe UI", 8)).pack(anchor="w", pady=(2, 0))

        self.tabs = ttk.Notebook(body)
        self.tabs.pack(fill="both", expand=True)
        self.dashboard_tab = tk.Frame(self.tabs, bg=BG)
        self.add_tab = tk.Frame(self.tabs, bg=BG)
        self.history_tab = tk.Frame(self.tabs, bg=BG)
        self.tabs.add(self.dashboard_tab, text="  Dashboard  ")
        self.tabs.add(self.add_tab, text="  Add Daily Habit  ")
        self.tabs.add(self.history_tab, text="  Habit History  ")
        self._build_dashboard()
        self._build_add()
        self._build_history()

        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill="x", padx=24, pady=(0, 12))
        tk.Label(footer, text="Your data is stored locally on this computer.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 8)).pack(side="left")
        self._button(footer, "Export CSV", self.do_export_csv, GREEN).pack(side="right", padx=(8, 0))
        self._button(footer, "Weekly Report", self.do_report, BLUE).pack(side="right")

    def _build_dashboard(self):
        card = tk.Frame(self.dashboard_tab, bg=CARD, highlightbackground="#E6EBF2", highlightthickness=1)
        card.pack(fill="both", expand=True, padx=3, pady=3)
        top = tk.Frame(card, bg=CARD)
        top.pack(fill="x", padx=18, pady=(16, 6))
        tk.Label(top, text="Weekly goal progress", bg=CARD, fg=NAVY,
                 font=("Segoe UI", 12, "bold")).pack(side="left")
        self.week_var = tk.StringVar()
        tk.Label(top, textvariable=self.week_var, bg=CARD, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="right")
        self.progress_rows = {}
        for key, label, color in [
            ("reading_minutes", "Reading", BLUE),
            ("exercise_minutes", "Exercise", GREEN),
            ("water_glasses", "Hydration", ORANGE),
        ]:
            row = tk.Frame(card, bg=CARD)
            row.pack(fill="x", padx=20, pady=12)
            tk.Label(row, text=label, bg=CARD, fg=NAVY,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w")
            bar = ttk.Progressbar(row, style="Blue.Horizontal.TProgressbar",
                                  maximum=100, length=500)
            if color == GREEN:
                bar.configure(style="Green.Horizontal.TProgressbar")
            elif color == ORANGE:
                bar.configure(style="Orange.Horizontal.TProgressbar")
            bar.pack(fill="x", pady=6)
            detail = tk.StringVar()
            tk.Label(row, textvariable=detail, bg=CARD, fg=MUTED,
                     font=("Segoe UI", 8)).pack(anchor="w")
            self.progress_rows[key] = (bar, detail)

        actions = tk.Frame(card, bg=CARD)
        actions.pack(fill="x", padx=18, pady=(12, 18))
        self._button(actions, "+ Add today's habits", lambda: self.tabs.select(self.add_tab)).pack(side="left")
        self._button(actions, "Create trend charts", self.do_charts, GREEN).pack(side="left", padx=8)

    def _build_add(self):
        outer = tk.Frame(self.add_tab, bg=CARD, highlightbackground="#E6EBF2", highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=3, pady=3)
        tk.Label(outer, text="Record your daily habits", bg=CARD, fg=NAVY,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=22, pady=(20, 4))
        tk.Label(outer, text="Enter your activity for one date. You can update an existing date.",
                 bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=22, pady=(0, 15))
        form = tk.Frame(outer, bg=CARD)
        form.pack(anchor="w", padx=22)
        self.form_vars = {
            "date": tk.StringVar(value=date.today().isoformat()),
            "reading": tk.StringVar(value=""),
            "exercise": tk.StringVar(value=""),
            "water": tk.StringVar(value=""),
            "notes": tk.StringVar(value=""),
        }
        fields = [
            ("Date (YYYY-MM-DD)", "date", 24),
            ("Reading (minutes)", "reading", 24),
            ("Exercise (minutes)", "exercise", 24),
            ("Water (glasses, 0-30)", "water", 24),
            ("Notes (optional, max 200 characters)", "notes", 48),
        ]
        for r, (label, key, width) in enumerate(fields):
            tk.Label(form, text=label, bg=CARD, fg=NAVY,
                     font=("Segoe UI", 9, "bold")).grid(row=r, column=0, sticky="w", pady=8)
            entry = tk.Entry(form, textvariable=self.form_vars[key], width=width,
                             font=("Segoe UI", 10), relief="solid", bd=1)
            entry.grid(row=r, column=1, sticky="w", padx=(18, 0), ipady=6)
        buttons = tk.Frame(outer, bg=CARD)
        buttons.pack(anchor="w", padx=22, pady=20)
        self._button(buttons, "Save habit record", self.save_form, GREEN).pack(side="left")
        tk.Button(buttons, text="Clear form", command=self.clear_form, bg="#EDF1F7",
                  fg=NAVY, relief="flat", padx=14, pady=9,
                  font=("Segoe UI", 9, "bold"), cursor="hand2").pack(side="left", padx=8)
        tk.Label(outer, text="Tip: If you save a date that already exists, the app will ask before replacing it.",
                 bg=CARD, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=22)

    def _build_history(self):
        outer = tk.Frame(self.history_tab, bg=CARD, highlightbackground="#E6EBF2", highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=3, pady=3)
        top = tk.Frame(outer, bg=CARD)
        top.pack(fill="x", padx=14, pady=14)
        tk.Label(top, text="Habit records", bg=CARD, fg=NAVY,
                 font=("Segoe UI", 13, "bold")).pack(side="left")
        self.search_var = tk.StringVar()
        search = tk.Entry(top, textvariable=self.search_var, width=26, font=("Segoe UI", 9),
                          relief="solid", bd=1)
        search.pack(side="right", padx=(6, 0), ipady=5)
        search.bind("<KeyRelease>", lambda _event: self.refresh_table())
        tk.Label(top, text="Search date / notes:", bg=CARD, fg=MUTED,
                 font=("Segoe UI", 8)).pack(side="right")
        columns = ("date", "reading", "exercise", "water", "notes")
        self.tree = ttk.Treeview(outer, columns=columns, show="headings")
        headings = [("date", "DATE", 130), ("reading", "READING (MIN)", 130),
                    ("exercise", "EXERCISE (MIN)", 140), ("water", "WATER (GLASSES)", 145),
                    ("notes", "NOTES", 350)]
        for key, title, width in headings:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="center" if key != "notes" else "w")
        self.tree.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self.tree.tag_configure("even", background="#F7F9FC")
        self.tree.tag_configure("odd", background="white")

    def clear_form(self):
        self.form_vars["date"].set(date.today().isoformat())
        for key in ("reading", "exercise", "water", "notes"):
            self.form_vars[key].set("")

    def save_form(self):
        try:
            entry_date = clean_date(self.form_vars["date"].get())
            reading = clean_integer(self.form_vars["reading"].get(), "Reading minutes")
            exercise = clean_integer(self.form_vars["exercise"].get(), "Exercise minutes")
            water = clean_integer(self.form_vars["water"].get(), "Water glasses", 0, 30)
            notes = clean_notes(self.form_vars["notes"].get())
        except ValueError as exc:
            messagebox.showerror("Check your entries", str(exc))
            return
        entry = HabitEntry(entry_date, reading, exercise, water, notes)
        existing = next((i for i, e in enumerate(self.entries) if e.entry_date == entry_date), None)
        if existing is not None:
            if not messagebox.askyesno("Replace record?", f"A record for {entry_date} already exists. Replace it?"):
                return
            self.entries[existing] = entry
        else:
            self.entries.append(entry)
        save_entries(self.entries)
        self.clear_form()
        self.refresh()
        messagebox.showinfo("Saved", "Your habit record has been saved.")
        self.tabs.select(self.dashboard_tab)

    def refresh(self):
        s = weekly_summary(self.entries)
        self.week_var.set(f"{s['start']}  —  {s['end']}")
        self.metric_vars["reading_minutes"].set(f"{s['totals']['reading_minutes']} min")
        self.metric_vars["exercise_minutes"].set(f"{s['totals']['exercise_minutes']} min")
        self.metric_vars["water_glasses"].set(f"{s['totals']['water_glasses']} glasses")
        self.reading_minutes_goal_var.set(f"Weekly goal: {GOALS['reading_minutes']} min")
        self.exercise_minutes_goal_var.set(f"Weekly goal: {GOALS['exercise_minutes']} min")
        self.water_glasses_goal_var.set(f"Weekly goal: {GOALS['water_glasses']} glasses")
        for key, (bar, detail) in self.progress_rows.items():
            pct = s["completion"][key]
            bar["value"] = pct
            detail.set(f"{s['totals'][key]} / {s['goals'][key]}  •  {pct:.0f}%  •  {habit_status(pct)}")
        self.refresh_table()

    def refresh_table(self):
        if not hasattr(self, "tree"):
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        results = search_entries(self.entries, self.search_var.get())
        for i, e in enumerate(sorted(results, key=lambda x: x.entry_date, reverse=True)):
            self.tree.insert("", "end", values=(e.entry_date, e.reading_minutes,
                             e.exercise_minutes, e.water_glasses, e.notes),
                             tags=("even" if i % 2 == 0 else "odd",))

    def do_export_csv(self):
        path = filedialog.asksaveasfilename(
            title="Export habit records", defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")], initialfile="habit_records.csv")
        if not path:
            return
        try:
            export_csv(self.entries, Path(path))
            messagebox.showinfo("Export complete", f"CSV saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))

    def do_report(self):
        path = filedialog.asksaveasfilename(
            title="Save weekly report", defaultextension=".txt",
            filetypes=[("Text files", "*.txt")], initialfile="weekly_report.txt")
        if not path:
            return
        try:
            Path(path).write_text(make_weekly_report(self.entries), encoding="utf-8")
            messagebox.showinfo("Report complete", f"Weekly report saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Report failed", str(exc))

    def do_charts(self):
        try:
            paths = create_charts(self.entries, EXPORT_DIR)
            first = paths[0]
            messagebox.showinfo("Charts created",
                "Three trend charts were saved in the exports folder:\n\n" +
                "\n".join(str(p) for p in paths))
            try:
                if sys.platform.startswith("win"):
                    os.startfile(first)
            except OSError:
                pass
        except (RuntimeError, ValueError, OSError) as exc:
            messagebox.showerror("Could not create charts", str(exc))

def run_gui():
    root = tk.Tk()
    HabitTrackerApp(root)
    root.mainloop()

if __name__ == "__main__":
    run_gui()
