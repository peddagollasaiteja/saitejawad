from datetime import date, timedelta
from collections import defaultdict
from config import GOALS

def week_start(value):
    day = date.fromisoformat(value)
    return day - timedelta(days=day.weekday())

def weekly_summary(entries, any_date=None):
    if any_date is None:
        any_date = date.today().isoformat()
    start = week_start(any_date)
    end = start + timedelta(days=6)
    selected = [e for e in entries if start.isoformat() <= e.entry_date <= end.isoformat()]
    totals = {
        "reading_minutes": sum(e.reading_minutes for e in selected),
        "exercise_minutes": sum(e.exercise_minutes for e in selected),
        "water_glasses": sum(e.water_glasses for e in selected),
    }
    completion = {
        key: min(100.0, totals[key] / goal * 100) if goal else 0.0
        for key, goal in GOALS.items()
    }
    return {
        "start": start.isoformat(), "end": end.isoformat(),
        "days_recorded": len(selected), "totals": totals,
        "goals": GOALS.copy(), "completion": completion,
        "entries": sorted(selected, key=lambda e: e.entry_date),
    }

def habit_status(percent):
    if percent >= 100:
        return "GOAL ACHIEVED"
    if percent >= 70:
        return "ON TRACK"
    return "NEEDS ATTENTION"

def search_entries(entries, keyword=""):
    key = keyword.strip().lower()
    if not key:
        return sorted(entries, key=lambda e: e.entry_date, reverse=True)
    return [e for e in entries if key in e.entry_date.lower() or key in e.notes.lower()]
