from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
JSON_FILE = DATA_DIR / "habits.json"
CSV_FILE = DATA_DIR / "habits.csv"

# Weekly goals are editable project settings.
GOALS = {
    "reading_minutes": 140,   # 20 minutes per day
    "exercise_minutes": 150,  # about 21 minutes per day
    "water_glasses": 56,      # 8 glasses per day
}
