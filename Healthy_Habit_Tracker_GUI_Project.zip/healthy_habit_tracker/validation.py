from datetime import date

def clean_date(value):
    value = value.strip()
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        raise ValueError("Date must use YYYY-MM-DD format.")
    if parsed > date.today():
        raise ValueError("Future dates are not allowed.")
    return parsed.isoformat()

def clean_integer(value, field, minimum=0, maximum=1440):
    try:
        number = int(value.strip())
    except (ValueError, AttributeError):
        raise ValueError(f"{field} must be a whole number.")
    if number < minimum or number > maximum:
        raise ValueError(f"{field} must be between {minimum} and {maximum}.")
    return number

def clean_notes(value):
    value = value.strip()
    if len(value) > 200:
        raise ValueError("Notes must be 200 characters or fewer.")
    return value
