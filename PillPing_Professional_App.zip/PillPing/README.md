# PillPing — Medication & Caregiver Management

A polished, front-end hackathon demo built with HTML, CSS and vanilla JavaScript.

## Run the app
1. Extract `PillPing.zip`.
2. Open the extracted `PillPing` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code **Live Server** extension and click **Go Live**.
4. Use the Overview, My medications, Caregiver portal and Adherence reports navigation.

## Demo features
- Senior-friendly medication overview and one-tap dose confirmation.
- Add, edit and delete medication schedules.
- Caregiver portal showing confirmations, pending doses and missed-dose flags.
- 30-minute missed-dose grace period, refill warnings below 5 doses.
- Weekly adherence view, browser notifications and browser speech capability-ready UI.
- Emergency caregiver quick dial.
- Data persists in the browser using LocalStorage.

## Demo notes / limitations
- This is a front-end prototype. It stores data in the current browser profile; it does not sync between separate devices or send real caregiver SMS/push alerts.
- The caregiver portal is a local demonstration view of the same patient account.
- A browser tab must remain open for scheduled reminders and missed-dose checks. Browser notifications require permission and HTTPS or localhost.
- Medication schedules and doses are demo data. Always follow a clinician's prescription; PillPing is not medical advice and does not verify physical ingestion.
- For production, add authenticated patient/caregiver accounts, a Node.js/Express API, a database, secure notification delivery, audit logs and privacy/security controls.
