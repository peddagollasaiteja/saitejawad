const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "pillping_professional_v1";
const slots = {Morning:"08:00",Afternoon:"13:00",Night:"20:00"};
const pretty = {Morning:"8:00 AM",Afternoon:"1:00 PM",Night:"8:00 PM"};
const colors = ["","pink","green-bg","yellow"];
const icons = ["✚","◉","✚","◌"];
const todayKey = () => new Date().toISOString().slice(0,10);
const defaultData = () => ({
  meds:[
    {id:"m1",name:"Amlodipine",dose:"5 mg",time:"Morning",food:"With water",stock:18},
    {id:"m2",name:"Metformin",dose:"500 mg",time:"Morning",food:"After food",stock:24},
    {id:"m3",name:"Aspirin",dose:"75 mg",time:"Afternoon",food:"After food",stock:3},
    {id:"m4",name:"Metformin",dose:"500 mg",time:"Night",food:"After food",stock:24}
  ], logs:{}, snoozes:{}, alerts:[], caregiverPhone:"+91 98765 43210"
});
let data = loadData(), activeDoseId = null, toastTimer;
function loadData(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||defaultData()}catch{return defaultData()}}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data));renderAll()}
function logKey(medId){return `${todayKey()}_${medId}`}
function getLog(med){return data.logs[logKey(med.id)]||null}
function doseState(med){
  const log=getLog(med); if(log?.status==="taken")return "taken";
  const now=new Date(), [h,m]=slots[med.time].split(":").map(Number);
  const due=new Date();due.setHours(h,m,0,0);
  if(data.snoozes[logKey(med.id)] && Date.now()<data.snoozes[logKey(med.id)])return "snoozed";
  if(now-due>30*60000)return "missed";
  return "pending";
}
function doseDate(med){const [h,m]=slots[med.time].split(":").map(Number);const d=new Date();d.setHours(h,m,0,0);return d}
function timeText(d){return d.toLocaleTimeString("en-IN",{hour:"numeric",minute:"2-digit"})}
function showToast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2600)}
function openModal(id){$(id).classList.add("show");$(id).setAttribute("aria-hidden","false")}
function closeModal(id){$(id).classList.remove("show");$(id).setAttribute("aria-hidden","true")}
function switchView(view){
 document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${view}`));
 document.querySelectorAll(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.view===view));
 const titles={overview:"Good morning, James",medications:"Your medication plan",caregiver:"Caregiver overview",reports:"Your progress, at a glance"};
 $("page-title").textContent=titles[view];$("sidebar").classList.remove("open");renderAll();window.scrollTo({top:0,behavior:"smooth"});
}
function markTaken(id){const med=data.meds.find(m=>m.id===id);if(!med)return;data.logs[logKey(id)]={status:"taken",at:new Date().toISOString()};delete data.snoozes[logKey(id)];if(med.stock>0)med.stock--;closeModal("dose-modal");save();showToast(`${med.name} marked as taken. Great job!`)}
function openDose(med){activeDoseId=med.id;$("dose-modal-name").textContent=`Time for ${med.name}`;$("dose-modal-detail").textContent=`${med.dose} · ${med.time} · ${pretty[med.time]}`;$("dose-modal-instruction").textContent=med.food;openModal("dose-modal")}
function renderToday(){
 const meds=[...data.meds].sort((a,b)=>slots[a.time].localeCompare(slots[b.time]));
 $("today-list").innerHTML=meds.length?meds.map((m,i)=>{const s=doseState(m);return `<div class="dose-row"><div class="dose-time">${pretty[m.time]}</div><div class="med-icon ${colors[i%4]}">${icons[i%4]}</div><div class="dose-info"><strong>${esc(m.name)}</strong><span>${esc(m.dose)} · ${esc(m.food)}</span></div>${s==="taken"?'<span class="dose-status">✓ Taken</span>':s==="missed"?'<span class="dose-status missed">Missed</span>':`<button class="dose-status pending" data-dose="${m.id}">Take dose</button>`}</div>`}).join(""):'<div class="empty-state">No medications added yet. Add your first medicine to get started.</div>';
 document.querySelectorAll("[data-dose]").forEach(b=>b.addEventListener("click",()=>openDose(data.meds.find(m=>m.id===b.dataset.dose))));
 const taken=meds.filter(m=>doseState(m)==="taken").length,missed=meds.filter(m=>doseState(m)==="missed").length;
 $("stat-total").textContent=meds.length;$("stat-taken").textContent=taken;$("stat-pending").textContent=meds.length-taken-missed;$("taken-caption").textContent=taken?`${taken} dose${taken>1?"s":""} completed today`:"Every dose counts";
 const next=meds.find(m=>doseState(m)!=="taken"&&doseState(m)!=="missed");
 $("next-title").textContent=next?`${next.name} · ${next.dose}`:"You're all caught up for now!";
 $("next-description").textContent=next?`${next.food}. Your next scheduled dose is ${pretty[next.time]}.`:"All scheduled doses are completed or reviewed.";
 $("next-time").textContent=next?pretty[next.time]:"✓";
}
function renderMeds(){
 $("med-count").textContent=`${data.meds.length} medicines`;
 $("med-summary").innerHTML=`<div class="summary-tile"><span>Active medicines</span><strong>${data.meds.length}</strong></div><div class="summary-tile"><span>Total doses in stock</span><strong>${data.meds.reduce((a,m)=>a+(+m.stock||0),0)}</strong></div><div class="summary-tile"><span>Low stock warnings</span><strong>${data.meds.filter(m=>m.stock<5).length}</strong></div>`;
 $("medication-list").innerHTML=data.meds.length?data.meds.map((m,i)=>`<div class="medication-item"><div class="med-icon ${colors[i%4]}">${icons[i%4]}</div><div class="dose-info"><strong>${esc(m.name)}</strong><div class="med-meta">${esc(m.dose)} · ${m.time} · ${esc(m.food)}</div></div><div class="stock ${m.stock<5?"low":""}">${m.stock<5?"⚠ ":""}${m.stock} doses left</div><div class="item-actions"><button class="mini-action" data-edit="${m.id}">Edit</button><button class="mini-action" data-delete="${m.id}">Delete</button></div></div>`).join(""):'<div class="empty-state">No medicines yet. Select “Add medication” to create your schedule.</div>';
 document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editMed(b.dataset.edit));
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{if(confirm("Delete this medication and its schedule?")){data.meds=data.meds.filter(m=>m.id!==b.dataset.delete);save();showToast("Medication deleted.")}});
}
function renderCare(){
 const states=data.meds.map(m=>({m,s:doseState(m)})),taken=states.filter(x=>x.s==="taken").length,missed=states.filter(x=>x.s==="missed").length,pending=states.length-taken-missed;
 $("care-taken").textContent=taken;$("care-pending").textContent=pending;$("care-missed").textContent=missed;
 $("care-dose-list").innerHTML=states.length?states.map(({m,s})=>`<div class="care-dose-row"><div class="med-icon">${icons[data.meds.indexOf(m)%4]}</div><div class="dose-info"><strong>${esc(m.name)}</strong><span>${pretty[m.time]} · ${esc(m.dose)}</span></div><span class="care-state ${s==="taken"?"taken":s==="missed"?"missed":"pending"}">${s==="taken"?"✓ Confirmed":s==="missed"?"! Missed":"Waiting"}</span></div>`).join(""):'<div class="empty-state">No medication schedule to monitor.</div>';
 const alerts=states.filter(x=>x.s==="missed"||x.m.stock<5);
 $("alert-count").textContent=alerts.length;$("alert-number").textContent=alerts.length;
 $("care-alerts").innerHTML=alerts.length?alerts.map(({m,s})=>`<div class="alert-item"><span class="alert-icon">${s==="missed"?"!":"▤"}</span><div><strong>${s==="missed"?"Missed dose: "+esc(m.name):"Refill needed: "+esc(m.name)}</strong><p>${s==="missed"?"No confirmation received 30 minutes after scheduled time.":`Only ${m.stock} doses remaining. Consider arranging a refill.`}</p></div></div>`).join(""):'<div class="no-alert">✓ No urgent alerts. Everything looks calm right now.</div>';
 $("care-contact").textContent=data.caregiverPhone;
}
function renderReports(){
 const taken=Object.entries(data.logs).filter(([k,v])=>v.status==="taken"&&k.startsWith(todayKey())).length;
 const score=data.meds.length?Math.round((taken/data.meds.length)*100):0;
 // Display a rolling illustrative weekly score; actual confirmations are stored locally.
 const weekly=Math.max(0,Math.min(100,Math.round((94+score)/2)));
 $("stat-score").textContent=`${weekly}%`;$("ring-score").textContent=`${weekly}%`;$("report-score").textContent=`${weekly}%`;
 $("progress-ring").style.background=`conic-gradient(#43b78f 0 ${weekly}%,#edf1f4 ${weekly}% 100%)`;
 const labels=["Fri","Sat","Sun","Mon","Tue","Wed","Thu"];
 $("week-bars").innerHTML=labels.map((d,i)=>`<div class="week-day"><div class="bar-track"><div class="bar-fill" style="height:${[72,90,100,84,96,88,weekly][i]}%"></div></div>${d}</div>`).join("");
 $("history-grid").innerHTML=labels.map((d,i)=>`<div class="history-day"><span>${d}</span><strong class="${i===6&&score<50?"partial":""}">${i===6?score>=100?"✓":score>=50?"•":"–":"✓"}</strong><small>${i===6?`${score}%`:"On track"}</small></div>`).join("");
 $("medicine-report").innerHTML=data.meds.map(m=>`<div class="report-med-row"><span>${esc(m.name)}</span><span>${m.stock<5?"Refill soon":"On schedule"}</span></div>`).join("")||'<div class="empty-state">Add medicines to see a breakdown.</div>';
}
function renderAll(){renderToday();renderMeds();renderCare();renderReports()}
function editMed(id){const m=data.meds.find(x=>x.id===id);if(!m)return;$("modal-title").textContent="Edit medication";$("med-id").value=m.id;$("med-name").value=m.name;$("med-dose").value=m.dose;$("med-time").value=m.time;$("med-food").value=m.food;$("med-stock").value=m.stock;openModal("med-modal")}
function resetForm(){$("med-form").reset();$("med-id").value="";$("modal-title").textContent="Add medication";$("med-stock").value=30}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("med-form").addEventListener("submit",e=>{e.preventDefault();const id=$("med-id").value||`m${Date.now()}`,existing=data.meds.find(m=>m.id===id);const med={id,name:$("med-name").value.trim(),dose:$("med-dose").value.trim(),time:$("med-time").value,food:$("med-food").value,stock:Math.max(0,+$("med-stock").value)};if(existing)Object.assign(existing,med);else data.meds.push(med);closeModal("med-modal");resetForm();save();showToast("Medication schedule saved.")});
$("add-med-btn").onclick=()=>{resetForm();openModal("med-modal")};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
$("confirm-dose").onclick=()=>activeDoseId&&markTaken(activeDoseId);
$("already-dose").onclick=()=>activeDoseId&&markTaken(activeDoseId);
$("speak-dose").onclick=()=>{
 const med=data.meds.find(m=>m.id===activeDoseId);
 if(!med)return;
 if(!("speechSynthesis" in window)){showToast("Voice assistance is not available in this browser.");return}
 window.speechSynthesis.cancel();
 const utterance=new SpeechSynthesisUtterance(`It is time for ${med.name}. Take ${med.dose}. Instructions: ${med.food}.`);
 utterance.rate=0.88;window.speechSynthesis.speak(utterance);
};
$("snooze-dose").onclick=()=>{if(!activeDoseId)return;data.snoozes[logKey(activeDoseId)]=Date.now()+15*60000;closeModal("dose-modal");save();showToast("Reminder snoozed for 15 minutes.")};
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>switchView(b.dataset.view));
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>switchView(b.dataset.go));
$("mobile-menu").onclick=()=>$("sidebar").classList.toggle("open");
$("sidebar-sos").onclick=$("call-caregiver").onclick=()=>{showToast("Opening your emergency contact…");window.location.href=`tel:${data.caregiverPhone.replace(/[^\d+]/g,"")}`};
$("notification-btn").onclick=async()=>{if(!("Notification"in window)){showToast("This browser does not support desktop notifications.");return}const p=await Notification.requestPermission();showToast(p==="granted"?"Notifications enabled on this device.":"Notification permission was not granted.")};
function checkDue(){
 const now=new Date();data.meds.forEach(m=>{const due=doseDate(m),key=logKey(m.id);if(due<=now&&now-due<60000&&!getLog(m)&&!data.snoozes[key]){if(document.visibilityState==="visible")openDose(m);if("Notification"in window&&Notification.permission==="granted")new Notification("PillPing medication reminder",{body:`Time for ${m.name} · ${m.dose}`})}});
 renderAll();
}
const now=new Date();$("today-label").textContent=now.toLocaleDateString("en-IN",{weekday:"long",month:"long",day:"numeric"}).toUpperCase();$("date-chip").textContent=now.toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
renderAll();setInterval(checkDue,30000);
